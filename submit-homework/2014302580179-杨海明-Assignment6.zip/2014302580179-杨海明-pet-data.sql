-- MySQL dump 10.13  Distrib 5.7.9, for osx10.9 (x86_64)
--
-- Host: localhost    Database: petstore
-- ------------------------------------------------------
-- Server version	5.7.9

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `2014302580179_pet`
--

LOCK TABLES `2014302580179_pet` WRITE;
/*!40000 ALTER TABLE `2014302580179_pet` DISABLE KEYS */;
INSERT INTO `2014302580179_pet` VALUES (1,'dog','bone','water','ground','play'),(2,'cat','fish','milk','roof','hug'),(3,'turtle','fish,shrimp','sea water','sea water','bask'),(4,'parrot','nuts,seeds','water','tree','fly'),(5,'hamster','Sunflower seed','water','corner','eat'),(6,'squirrel','pine cone','water','tree hole,underground','play'),(7,'rabbit','carrot','water','grassland,underground','eat'),(8,'snake','mouse','water','hole','bask'),(9,'lizard','bug','water','tree','bask'),(10,'fish','aquatic plant','water','water','swim'),(11,'myna','earthworm','water','tree','fly'),(12,'canary','millet','water','tree','sing');
/*!40000 ALTER TABLE `2014302580179_pet` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-12-13 21:54:25
