package model;

public class Pet {
	 private String name, eat, drink, live, hobby;
	 private int id;

	    public Pet(int id,String name, String eat, String drink, String live, String hobby)
	    {
	        this.id = id;
	    		this.name = name;
	        this.eat = eat;
	        this.drink = drink;
	        this.live = live;
	        this.hobby = hobby;
	       
	    }

	    public String getName()
	    {
	        return name;
	    }

	    public String getEat()
	    {
	        return eat;
	    }

	    public String getDrink()
	    {
	        return drink;
	    }

	    public String getLive()
	    {
	        return live;
	    }

	    public String getHobby()
	    {
	        return hobby;
	    }

	    public int getId()
	    {
	        return id;
	    }


}
