package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import controller.DBService;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Color;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class RegistGUI extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private DBService db = new DBService();
	//private static RegistGUI registGUI = new RegistGUI();
	//单例模式
	private static RegistGUI singleton = null;
	private JTextField textField_name;
	private JTextField textField_pw;
	private JTextField textField_email;
	private JTextField textField_tel;
	public static RegistGUI getInstance() {
		if (singleton == null) {
			singleton = new RegistGUI();
		}
		
		return singleton;
	}

	/**
	 * Launch the application.
	 */
	public void initialize() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RegistGUI frame = new RegistGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}


	
	/**
	 * Create the frame.
	 */
	public RegistGUI() {
		setTitle("PetStore");
		setBackground(Color.WHITE);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 300, 450);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblRegist = new JLabel("Regist");
		lblRegist.setFont(new Font("Lucida Grande", Font.PLAIN, 30));
		lblRegist.setBounds(97, 32, 133, 59);
		contentPane.add(lblRegist);
		
		JLabel lblNickName = new JLabel("User Name:");
		lblNickName.setBounds(26, 100, 78, 16);
		contentPane.add(lblNickName);
		
		JLabel lblPassword = new JLabel("Password:");
		lblPassword.setBounds(26, 165, 78, 16);
		contentPane.add(lblPassword);
		
		JLabel lblEmail = new JLabel("Email:");
		lblEmail.setBounds(26, 226, 78, 16);
		contentPane.add(lblEmail);
		
		JLabel lblTel = new JLabel("Tel:");
		lblTel.setBounds(26, 288, 78, 16);
		contentPane.add(lblTel);
		
		textField_name = new JTextField();
		textField_name.setBounds(26, 125, 248, 28);
		contentPane.add(textField_name);
		textField_name.setColumns(10);
		
		textField_pw = new JTextField();
		textField_pw.setColumns(10);
		textField_pw.setBounds(26, 193, 248, 28);
		contentPane.add(textField_pw);
		
		textField_email = new JTextField();
		textField_email.setColumns(10);
		textField_email.setBounds(26, 254, 248, 28);
		contentPane.add(textField_email);
		
		textField_tel = new JTextField();
		textField_tel.setColumns(10);
		textField_tel.setBounds(26, 316, 248, 28);
		contentPane.add(textField_tel);
		
		JButton btnSubmit = new JButton("Submit");
		btnSubmit.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String newUsername = textField_name.getText();
                String newPassword = textField_pw.getText();
                String newEmail = textField_email.getText();
                String newtel = textField_tel.getText();
                
                boolean isEmailVaild = db.isEmailVaild(newEmail);

                if (!newUsername.equals("") && !newPassword.equals("")&&!newEmail.equals("") &&!newtel.equals("") )
                {
                	int int_newTel = Integer.valueOf(textField_tel.getText());
                 if (isEmailVaild) {
                	db.addNewUser(newUsername, newPassword, newEmail, int_newTel);
                	 JOptionPane.showConfirmDialog(null, "Regist successfully,and then will return to login",
                             null, JOptionPane.CANCEL_OPTION);
                	LoginGUI.getInstance();
     			singleton.dispose();
				}
                 else{
                	 JOptionPane.showConfirmDialog(null, "Email address is invaild,please try again.",
                             null, JOptionPane.CANCEL_OPTION);
                 }
                }
                else{
                	JOptionPane.showConfirmDialog(null, "Please complete the form.",
                            null, JOptionPane.CANCEL_OPTION);
                }
				
				
			}
		});
		btnSubmit.setBounds(97, 371, 117, 29);
		contentPane.add(btnSubmit);
	}
}
