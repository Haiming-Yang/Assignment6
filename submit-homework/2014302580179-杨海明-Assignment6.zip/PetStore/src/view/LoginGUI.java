package view;


import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;

import controller.DBService;

import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class LoginGUI {

	private JFrame frmPetstore;
	private JTextField textField_name;
	private JTextField textField_pw;
	private DBService db = new DBService();
	//private static RegistGUI registGUI = new RegistGUI();
	private static LoginGUI singleton = null;
	public static LoginGUI getInstance() {
		if (singleton == null) {
			singleton = new LoginGUI();
		}
		
		return singleton;
	}
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginGUI window = new LoginGUI();
					window.frmPetstore.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public LoginGUI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmPetstore = new JFrame();
		frmPetstore.setTitle("PetStore");
		frmPetstore.setVisible(true);
		frmPetstore.getContentPane().setBackground(Color.WHITE);
		frmPetstore.getContentPane().setLayout(null);
		
		JLabel lblLogin = new JLabel("Login");
		lblLogin.setFont(new Font("Lucida Grande", Font.PLAIN, 30));
		lblLogin.setBounds(105, 35, 133, 59);
		frmPetstore.getContentPane().add(lblLogin);
		
		JLabel lblName = new JLabel("Name:");
		lblName.setFont(new Font("Lucida Grande", Font.PLAIN, 18));
		lblName.setBounds(34, 118, 61, 16);
		frmPetstore.getContentPane().add(lblName);
		
		textField_name = new JTextField();
		textField_name.setBounds(34, 147, 236, 28);
		frmPetstore.getContentPane().add(textField_name);
		textField_name.setColumns(10);
		
		JLabel lblPassword = new JLabel("Password:");
		lblPassword.setFont(new Font("Lucida Grande", Font.PLAIN, 18));
		lblPassword.setBounds(34, 187, 87, 16);
		frmPetstore.getContentPane().add(lblPassword);
		
		textField_pw = new JTextField();
		textField_pw.setColumns(10);
		textField_pw.setBounds(34, 215, 236, 28);
		frmPetstore.getContentPane().add(textField_pw);
		
		JButton btnNewButton = new JButton("Not have an account yet?");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				RegistGUI.getInstance().initialize();
				
				frmPetstore.dispose();
			}
		});
		btnNewButton.setBounds(61, 349, 191, 29);
		frmPetstore.getContentPane().add(btnNewButton);
		
		JButton btnGo = new JButton("GO");
		btnGo.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String username = textField_name.getText();
                String password = textField_pw.getText();

                boolean isAuthenticated = false;
                try
                {
                    isAuthenticated = db.isAuthenticated(username, password);
                } catch (Exception e1)
                {
                    e1.printStackTrace();
                }

                if (!username.equals("") && !password.equals(""))
                {
                    if (isAuthenticated)
                    {
                    
                    	StoreGUI.getInstance().initialize();
        				frmPetstore.dispose();
//                        try
//                        {
//                            pets = DBUtils.getPetsData();
//                        } catch (Exception e)
//                        {
//                            e.printStackTrace();
//                        }
//                        for (int i = 0; i < 12; i++)
//                        {
//                            mostNumber[i] = Integer.parseInt(pets.get(i).getNumber());
//                        }
//
//                        showPetStore();
                    }
                    else
                    {
                        JOptionPane.showConfirmDialog(null, "Wrong username or password.",
                                null, JOptionPane.CANCEL_OPTION);
                    }
                }
                else {
                	JOptionPane.showConfirmDialog(null, "Please input the name and password.",
                            null, JOptionPane.CANCEL_OPTION);
				}
				
			}
		});
		btnGo.setBackground(Color.BLUE);
		btnGo.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		btnGo.setBounds(105, 268, 87, 45);
		frmPetstore.getContentPane().add(btnGo);
		frmPetstore.setBackground(Color.WHITE);
		frmPetstore.setResizable(false);
		frmPetstore.setBounds(100, 100, 300, 450);
		frmPetstore.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
