package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import model.Purchased;

import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

public class PurchasedGUI extends JFrame {
	/**
	 * 
	 */
	public static ArrayList<Purchased> purchasedList = new ArrayList<>();
	private static final long serialVersionUID = 1L;
		//单例模式
		private static PurchasedGUI singleton = null;
		public static PurchasedGUI getInstance() {
			if (singleton == null) {
				singleton = new PurchasedGUI();
			}
			
			return singleton;
		}

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public void initialize() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PurchasedGUI frame = new PurchasedGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public PurchasedGUI() {
		setTitle("PetStore");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 300, 450);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblPurchased = new JLabel("Purchased");
		lblPurchased.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		lblPurchased.setBounds(20, 6, 107, 43);
		contentPane.add(lblPurchased);
		
		JButton btnStore = new JButton("Store");
		btnStore.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				StoreGUI.getInstance().initialize();
				singleton.dispose();
			}
		});
		btnStore.setBounds(172, 17, 57, 29);
		contentPane.add(btnStore);
		
		JButton button = new JButton("Cart");
		button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				CartGUI.getInstance().initialize();
				singleton.dispose();
			}
		});
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		button.setBounds(237, 17, 57, 29);
		contentPane.add(button);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBounds(28, 74, 239, 337);
		contentPane.add(panel);
		panel.setLayout(new GridLayout(purchasedList.size(), 1));
		
		for (Purchased purchased : purchasedList) {
			JLabel temp = new JLabel(purchased.getName());
			panel.add(temp);
		}
	}
	

}
