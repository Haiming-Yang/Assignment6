package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import controller.DBService;
import model.Cart;
import model.Pet;
import model.Purchased;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class StoreGUI extends JFrame {
	/**
	 * 
	 */
	private DBService db = new DBService();
	ArrayList<Pet> petList = db.readDB();
	private int selectedId = 0;
	private static final long serialVersionUID = 1L;
		//单例模式
		private static StoreGUI singleton = null;
		public static StoreGUI getInstance() {
			if (singleton == null) {
				singleton = new StoreGUI();
			}
			
			return singleton;
		}

	private JPanel contentPane;
	private final JScrollPane scrollPane = new JScrollPane();

	/**
	 * Launch the application.
	 */
	public void initialize() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StoreGUI frame = new StoreGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public StoreGUI() {
		setTitle("PetStore");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 300, 450);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblStore = new JLabel("Store");
		lblStore.setBounds(20, 17, 61, 25);
		lblStore.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		contentPane.add(lblStore);
		
		JButton btnCart = new JButton("Cart");
		btnCart.setBounds(124, 13, 61, 29);
		btnCart.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				CartGUI.getInstance().initialize();
				singleton.dispose();
			}
		});
		contentPane.add(btnCart);
		
		JButton btnPurchased = new JButton("Purchased");
		btnPurchased.setBounds(192, 13, 96, 29);
		btnPurchased.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				PurchasedGUI.getInstance().initialize();
				singleton.dispose();
			}
		});
		contentPane.add(btnPurchased);
		scrollPane.setBounds(0, 54, 300, 119);
		contentPane.add(scrollPane);
		
		JTextArea txtr_info = new JTextArea();
		txtr_info.setText("Please select the pet which you want to see more infomation.\nAfter you selected a pet, you can buy it immidiately by pressing\"Buy now\" or add it to your cart by pressing\"Add to cart\".");
		txtr_info.setToolTipText("");
		txtr_info.setWrapStyleWord(true);
		txtr_info.setEditable(false);
		txtr_info.setLineWrap(true);
		scrollPane.setViewportView(txtr_info);
		
		
		JButton btnBuyNow = new JButton("Buy now");
		btnBuyNow.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name = petList.get(selectedId-1).getName();
				int id = petList.get(selectedId-1).getId();
				Purchased newPurchased = new Purchased(id, name);
				PurchasedGUI.purchasedList.add(newPurchased);
				//btnAddToCart.setEnabled(false);
				btnBuyNow.setEnabled(false);
				JOptionPane.showConfirmDialog(null, "Success!You can see what you have bought in [purchased] page.",
                        null, JOptionPane.CANCEL_OPTION);
			}
		});
		btnBuyNow.setEnabled(false);
		btnBuyNow.setBounds(202, 369, 86, 34);
		contentPane.add(btnBuyNow);
		
		JButton btnAddToCart = new JButton("Add to cart");
		btnAddToCart.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name = petList.get(selectedId-1).getName();
				int id = petList.get(selectedId-1).getId();
				Cart newCart = new Cart(id, name);
				CartGUI.cartList.add(newCart);
				btnAddToCart.setEnabled(false);
				btnBuyNow.setEnabled(false);
				JOptionPane.showConfirmDialog(null, "Success!You can see what you have added in [cart] page.",
                        null, JOptionPane.CANCEL_OPTION);
				
			}
		});
		btnAddToCart.setEnabled(false);
		btnAddToCart.setBounds(10, 369, 86, 34);
		contentPane.add(btnAddToCart);
		
		JButton btn1 = new JButton("");
		btn1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtr_info.setText(
						"Name:     " + petList.get(0).getName() +
		                "\nEat:    " + petList.get(0).getEat() +
		                "\nDrink:  " + petList.get(0).getDrink() +
		                "\nLive:   " + petList.get(0).getLive() +
		                "\nHobby:  " + petList.get(0).getHobby()
		                );
						selectedId = petList.get(0).getId();
						btnAddToCart.setEnabled(true);
						btnBuyNow.setEnabled(true);
						
			}
		});
		btn1.setText(petList.get(0).getName());
		btn1.setBounds(10, 185, 86, 34);
		contentPane.add(btn1);
		
		JButton btn2 = new JButton("");
		btn2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtr_info.setText("Name:     " + petList.get(1).getName() +
		                "\nEat:    " + petList.get(1).getEat() +
		                "\nDrink:  " + petList.get(1).getDrink() +
		                "\nLive:   " + petList.get(1).getLive() +
		                "\nHobby:  " + petList.get(1).getHobby());
						selectedId = petList.get(1).getId();
						btnAddToCart.setEnabled(true);
						btnBuyNow.setEnabled(true);
			}
		});
		btn2.setText(petList.get(1).getName());
		btn2.setBounds(106, 185, 86, 34);
		contentPane.add(btn2);
		
		JButton btn3 = new JButton("");
		btn3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtr_info.setText("Name:     " + petList.get(2).getName() +
		                "\nEat:    " + petList.get(2).getEat() +
		                "\nDrink:  " + petList.get(2).getDrink() +
		                "\nLive:   " + petList.get(2).getLive() +
		                "\nHobby:  " + petList.get(2).getHobby());
				
						selectedId = petList.get(2).getId();
						btnAddToCart.setEnabled(true);
						btnBuyNow.setEnabled(true);
			}
		});
		btn3.setText(petList.get(2).getName());
		btn3.setBounds(204, 185, 84, 34);
		contentPane.add(btn3);
		
		JButton btn4 = new JButton("");
		btn4.setText(petList.get(3).getName());
		btn4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtr_info.setText("Name:     " + petList.get(3).getName() +
		                "\nEat:    " + petList.get(3).getEat() +
		                "\nDrink:  " + petList.get(3).getDrink() +
		                "\nLive:   " + petList.get(3).getLive() +
		                "\nHobby:  " + petList.get(3).getHobby());
						selectedId = petList.get(3).getId();
						btnAddToCart.setEnabled(true);
						btnBuyNow.setEnabled(true);
			}
		});
		btn4.setBounds(10, 231, 86, 34);
		contentPane.add(btn4);
		
		JButton btn5 = new JButton("");
		btn5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtr_info.setText("Name:     " + petList.get(4).getName() +
		                "\nEat:    " + petList.get(4).getEat() +
		                "\nDrink:  " + petList.get(4).getDrink() +
		                "\nLive:   " + petList.get(4).getLive() +
		                "\nHobby:  " + petList.get(4).getHobby());
						selectedId = petList.get(4).getId();
						btnAddToCart.setEnabled(true);
						btnBuyNow.setEnabled(true);
			}
		});
		btn5.setText(petList.get(4).getName());
		btn5.setBounds(106, 231, 86, 34);
		contentPane.add(btn5);
		
		JButton btn6 = new JButton("");
		btn6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtr_info.setText("Name:     " + petList.get(5).getName() +
		                "\nEat:    " + petList.get(5).getEat() +
		                "\nDrink:  " + petList.get(5).getDrink() +
		                "\nLive:   " + petList.get(5).getLive() +
		                "\nHobby:  " + petList.get(5).getHobby());
						selectedId = petList.get(5).getId();
						btnAddToCart.setEnabled(true);
						btnBuyNow.setEnabled(true);
			}
		});
		btn6.setText(petList.get(5).getName());
		btn6.setBounds(202, 231, 86, 34);
		contentPane.add(btn6);
		
		JButton btn7 = new JButton("");
		btn7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtr_info.setText("Name:     " + petList.get(6).getName() +
		                "\nEat:    " + petList.get(6).getEat() +
		                "\nDrink:  " + petList.get(6).getDrink() +
		                "\nLive:   " + petList.get(6).getLive() +
		                "\nHobby:  " + petList.get(6).getHobby());
						selectedId = petList.get(6).getId();
						btnAddToCart.setEnabled(true);
						btnBuyNow.setEnabled(true);
			}
		});
		btn7.setText(petList.get(6).getName());
		btn7.setBounds(10, 277, 86, 34);
		contentPane.add(btn7);
		
		JButton btn8 = new JButton("");
		btn8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtr_info.setText("Name:     " + petList.get(7).getName() +
		                "\nEat:    " + petList.get(7).getEat() +
		                "\nDrink:  " + petList.get(7).getDrink() +
		                "\nLive:   " + petList.get(7).getLive() +
		                "\nHobby:  " + petList.get(7).getHobby());
						selectedId = petList.get(7).getId();
						btnAddToCart.setEnabled(true);
						btnBuyNow.setEnabled(true);
			}
		});
		btn8.setText(petList.get(7).getName());
		btn8.setBounds(106, 277, 86, 34);
		contentPane.add(btn8);
		
		JButton btn9 = new JButton("");
		btn9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtr_info.setText("Name:     " + petList.get(8).getName() +
		                "\nEat:    " + petList.get(8).getEat() +
		                "\nDrink:  " + petList.get(8).getDrink() +
		                "\nLive:   " + petList.get(8).getLive() +
		                "\nHobby:  " + petList.get(8).getHobby());
						selectedId = petList.get(8).getId();
						btnAddToCart.setEnabled(true);
						btnBuyNow.setEnabled(true);
			}
		});
		btn9.setText(petList.get(8).getName());
		btn9.setBounds(202, 277, 86, 34);
		contentPane.add(btn9);
		
		JButton btn10 = new JButton("");
		btn10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtr_info.setText("Name:     " + petList.get(9).getName() +
		                "\nEat:    " + petList.get(9).getEat() +
		                "\nDrink:  " + petList.get(9).getDrink() +
		                "\nLive:   " + petList.get(9).getLive() +
		                "\nHobby:  " + petList.get(9).getHobby());
						selectedId = petList.get(9).getId();
						btnAddToCart.setEnabled(true);
						btnBuyNow.setEnabled(true);
			}
		});
		btn10.setText(petList.get(9).getName());
		btn10.setBounds(10, 323, 86, 34);
		contentPane.add(btn10);
		
		JButton btn11 = new JButton("");
		btn11.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtr_info.setText("Name:     " + petList.get(10).getName() +
		                "\nEat:    " + petList.get(10).getEat() +
		                "\nDrink:  " + petList.get(10).getDrink() +
		                "\nLive:   " + petList.get(10).getLive() +
		                "\nHobby:  " + petList.get(10).getHobby());
				selectedId = petList.get(10).getId();
			}
		});
		btn11.setText(petList.get(10).getName());
		btn11.setBounds(106, 323, 86, 34);
		contentPane.add(btn11);
		
		JButton btn12 = new JButton("");
		btn12.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtr_info.setText("Name:     " + petList.get(11).getName() +
		                "\nEat:    " + petList.get(11).getEat() +
		                "\nDrink:  " + petList.get(11).getDrink() +
		                "\nLive:   " + petList.get(11).getLive() +
		                "\nHobby:  " + petList.get(11).getHobby());
						selectedId = petList.get(11).getId();
						btnAddToCart.setEnabled(true);
						btnBuyNow.setEnabled(true);
			}
		});
		btn12.setText(petList.get(11).getName());
		btn12.setBounds(202, 323, 86, 34);
		contentPane.add(btn12);

	}
}
