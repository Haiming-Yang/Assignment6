package view;


import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;



import model.Cart;
import model.Purchased;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JCheckBox;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

public class CartGUI extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	public  static ArrayList<Cart> cartList = new ArrayList<>();
	//单例模式
		private static CartGUI singleton = null;
		public static CartGUI getInstance() {
			if (singleton == null) {
				singleton = new CartGUI();
			}
			
			return singleton;
		}


	/**
	 * Launch the application.
	 */
	public void initialize() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CartGUI frame = new CartGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CartGUI() {
		setTitle("PetStore");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 300, 450);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblCart = new JLabel("Cart");
		lblCart.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		lblCart.setBounds(27, 18, 61, 25);
		contentPane.add(lblCart);
		
		JButton btnStore = new JButton("Store");
		btnStore.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				StoreGUI.getInstance().initialize();
				singleton.dispose();
			}
		});
		btnStore.setBounds(137, 14, 69, 29);
		contentPane.add(btnStore);
		
		JButton btnPurchased = new JButton("Purchased");
		btnPurchased.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				PurchasedGUI.getInstance().initialize();
				singleton.dispose();
			}
		});
		btnPurchased.setBounds(206, 14, 88, 29);
		contentPane.add(btnPurchased);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBounds(6, 65, 288, 311);
		contentPane.add(panel);
		panel.setLayout(new GridLayout(cartList.size(), 1));
		
		JButton btnNewButton = new JButton("Buy now");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				for (Cart cart : cartList) {
					String name = cart.getName();
					int id = cart.getId();
					Purchased newPurchased = new Purchased(id, name);
					PurchasedGUI.purchasedList.add(newPurchased);
				}
				JOptionPane.showConfirmDialog(null, "Success!You can see what you have bought in [purchased] page.",
                        null, JOptionPane.CANCEL_OPTION);


			}
		});
		btnNewButton.setBounds(153, 393, 117, 29);
		contentPane.add(btnNewButton);
		for (Cart cart : cartList) {
			JCheckBox temp = new JCheckBox(cart.getName());
			temp.addActionListener(new ActionListener(){
				@Override
				public void actionPerformed(ActionEvent e){
					//if(temp.isSelected())
						
					if(!temp.isSelected()){
						cartList.remove(cart.getId());
					}
						
				}
			});
		
			panel.add(temp);
			
		}
		
		
		
	}
}
