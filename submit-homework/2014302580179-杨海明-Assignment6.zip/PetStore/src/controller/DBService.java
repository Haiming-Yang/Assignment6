package controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import model.Pet;

public class DBService {

	//private String url = "jdbc:mysql://127.0.0.1:3306/petstore?"  + "user=root&password=Yhm12345.&useUnicode=true&characterEncoding=UTF8";;
	private String url = "jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456";
	private String sql1 = "select * from 2014302580179_pet ";
	private String sql2 = "select * from 2014302580179_Customer ";
	private Connection getConnection(String url) {
	    Connection con = null;
		try {
	        con = DriverManager.getConnection(url);
	      } catch (SQLException e1) {
	        e1.printStackTrace();
	      }
	      try
	      {
	        Class.forName("com.mysql.jdbc.Driver");
	      } catch (ClassNotFoundException e) {
	        e.printStackTrace();
	      }
	      return con;
	}
	public ArrayList<Pet> readDB(){
		ArrayList< Pet> petList = new ArrayList<>();
		try
	    {
	    	  ResultSet rs;  
	      Statement sttm = getConnection(url).prepareStatement(sql1);
	      rs = sttm.executeQuery(sql1);
	      
	      
	      
	      while(rs.next()){
	      int id = rs.getInt(1);
	    	  String name = rs.getString(2);
	      String eat = rs.getString(3);
	      String drink = rs.getString(4);
	      String live = rs.getString(5);
	      String hobby = rs.getString(6);
	      
	    	  Pet petInfo = new Pet(id, name,eat,drink,live,hobby);
	    	  petList.add(petInfo);
	    	 //System.out.println(petInfo.getId());
	      }
	      sttm.close();
	      getConnection(url).close();
	      
	    } catch (SQLException e) {
	      e.printStackTrace();
	    }

	return petList;
}
	
	 public  void addNewUser(String user, String password,String email, int tel) 
	    {
		try {
		 Statement sttm = getConnection(url).createStatement();
		sttm.execute("INSERT INTO Customer VALUES ('" + user + "','" + password + "','" + email + "','" + tel + "')");
		}
		catch (SQLException e) {
		      e.printStackTrace();
		    }

	    }

	    public  boolean isAuthenticated(String user, String password) 
	    {
	        boolean isAuthenticated = false;
	        try{
	        Statement sttm = getConnection(url).createStatement();

	        ResultSet rs = sttm.executeQuery(sql2);

	        while (rs.next())
	        {
	            if (user.equals(rs.getString("Username")) && password.equals(rs.getString("Password")))
	            {
	                isAuthenticated = true;
	                //System.out.println("success");
	                break;
	            }
	        }
	        }
			catch (SQLException e) {
			    e.printStackTrace();
			}
	        return isAuthenticated;
	    }
	public boolean isEmailVaild(String email){
		boolean isVaild = false;
		String mailRegex = "^([a-zA-Z0-9]*[-_]?[a-zA-Z0-9]+)*@([a-zA-Z0-9]*[-_]?[a-zA-Z0-9]+)+[\\.][A-Za-z]{2,3}([\\.][A-Za-z]{2})?$";
		Pattern mailPattern = Pattern.compile(mailRegex);
		Matcher matcher = mailPattern.matcher(email);
		if (matcher.find()) {
			isVaild = true;
		}
		return isVaild;
	}

}
